﻿namespace GetSumDiv7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine($"Summe.... 1;23 = {GetSumDiv7(1,23)}");
            Console.WriteLine($"Summe.... 1;100 = {GetSumDiv7(1,100)}");
        }

        public static uint GetSumDiv7(uint from, uint to)
        {
            uint summe = 0;

            for (uint i = from; i < to; i++)
            {
                if (i % 7 == 0) summe += i; 
            }

            return summe;
        }
       
    }
}
﻿// See https://aka.ms/new-console-template for more information

static void execute()
{
    for (uint i = 0; i <= 100; i++)
    {
        if (IsPrime(i))
        {
            Console.WriteLine(i);
        }

    }

    uint result = CalcPrim(2, 54);
    Console.WriteLine($"Anzahl ist {result}");
}



static bool IsPrime(uint value)
{
    if(value < 2)
    {
        return false;
    } else if (value == 2)
    {
        return true;
    } else
    {
        if(value % 2 == 0) return false;
        for(uint i = 3; i <= value/i; i +=2) // weil schon auf die geraden Zahlen geprüft wird i +=2
        {
            if (value % i == 0) return false;
        }
        return true;
    }
}

static uint CalcPrim(uint p1, uint p2)
{
    uint anz = 0;

    for (uint zahl = p1+1; zahl < p2; zahl++)
    {
        if(IsPrime(zahl)) anz++;
    }

    return anz;
}


execute();


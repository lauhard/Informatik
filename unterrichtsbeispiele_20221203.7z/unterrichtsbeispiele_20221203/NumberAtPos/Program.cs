﻿namespace NumberAtPos
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(GetNumberAtPos(1023,0));
            Console.WriteLine(GetNumberAtPos(1023,1));
            Console.WriteLine(GetNumberAtPos(1023,2));
            Console.WriteLine(GetNumberAtPos(1023,3));
            Console.WriteLine(GetNumberAtPos(1023,4));
        }

        public static uint GetNumberAtPos(uint number, uint pos)
        {
            //shift left
            while (pos > 0) { number /= 10; pos--; }
            return number % 10;
        }
    }
}
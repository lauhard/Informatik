﻿namespace Power
{
    internal class Program
    {
        static void Main(string[] args)
        {
            for (int i = -10; i < 11; i++)
            {
                Console.WriteLine($" 2^{i} = {Power(2, i)}"); 
            }
        }

        public static double Power(double a, int b)
        {
            double a_hoch_b = 1;
            if(b > 0)
            {
                for (int i = 1; i <= b; i++)
                {
                    a_hoch_b *= a;
                }
            } else if(b < 0)
            {
                a_hoch_b = 1 / Power(a, -b); // nice trick für negetive Werte
            }
            return a_hoch_b;
        }
    }
}
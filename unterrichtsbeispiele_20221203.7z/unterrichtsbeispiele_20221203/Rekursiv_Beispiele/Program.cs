﻿namespace Rekursiv_Beispiele
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            PowerRec(9, 2);

        }




        /**
         * Rekursionsbasis
         * -Abbruchbedingung
         * 
         * Rekursionsschritt
         * 
         * ---------------------------------
         * 
         * Wann einsetzten
         * - teile und Hersce
         * - Bearbeitung der Baumstruktur
         */

        /**
        *       #==>    1         : b=0
        *       #
        *       #
        *a^b =  #==>     a*a^(b-1) : b > 0
        *       #
        *       #
        *       #==>     1/a^(-b)  : b < 0
        */

        public static double PowerRec(double a, int b)
        {
            //if(b == 1)
            //{
            //    Console.WriteLine("\n" +
            //    "*       #==>    1         : b=0   \n" +
            //    "*       #                         \n" +
            //    "*       #                         \n" +
            //    "*a^b =  #==>     a*a^(b-1) : b > 0\n" +
            //    "*       #                         \n" +
            //    "*       #                         \n" +
            //    "*       #==>     1/a^(-b)  : b < 0\n" +
            //    "*/"
            //    );
            //}

            Console.WriteLine("Aufruf mint a={0} und b={1}", a, b);
            double a_hoch_b = 1;
            if (b < 0)
            {
                a_hoch_b = a * PowerRec(a, b - 1);    
            } else if (b > 0)
            {
                a_hoch_b = 1 / PowerRec(a, -b);
            }
            Console.WriteLine("Ergebnis {0} {1} = {2}", a, b, a_hoch_b);
            return a_hoch_b;

        }
    }
}